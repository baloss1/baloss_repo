from ipcqueue import posixmq
qA = posixmq.Queue('/A')
qB = posixmq.Queue('/B')
qC = posixmq.Queue('/C')