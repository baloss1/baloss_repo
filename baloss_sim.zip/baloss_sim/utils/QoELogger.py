##Created by Wei Lai on 2020/12/15 12:21 (UTC+8)
#QoE Logger Class

class QoELogger:
    def __init__(self,logfile,type):
        self.logfile = logfile
        if type == 0:
            with open(logfile,'w') as f1:
                f1.write("delay,loss,goodput\n")
        else:
            with open(logfile,'w') as f1:
                f1.write("r,c,f\n")
    def record(self,raw_qoe):
        record_line = str(raw_qoe[0])+','+str(raw_qoe[1])+','+str(raw_qoe[2])+'\n'
        with open(self.logfile,'a') as f1:
            f1.write(record_line)

