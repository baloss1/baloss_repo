import csv
import logging
import argparse
from collections import namedtuple
import random

def gen_random_trace_fix(length):
    trace = []
    for i in range(length):
        per = 0
        ber = 0
        bandwidth = 1000
        rtt = 10
        record = {'per':per,'ber':ber,'bandwidth':bandwidth,'rtt':rtt}
        trace.append(record)
    return trace

def gen_random_trace_normal(length):
    trace = []
    for i in range(length):
        per = random.random()
        ber = random.random()
        while (ber + per > 1):
            ber = random.random()
        bandwidth = 10000
        rtt = 100 + random.randint(1,100)
        record = {'per':per,'ber':ber,'bandwidth':bandwidth,'rtt':rtt}
        trace.append(record)
    return trace

def write_trace_as_csv(trace,csvfile):
    logging.debug(trace)
    headers = ['per','ber','bandwidth','rtt']
    with open(csvfile,'w') as f:
        f_csv = csv.DictWriter(f, headers)
        f_csv.writeheader()
        f_csv.writerows(trace)

def check_valid_trace(csvfile):
    return True

def display_csv_as_trace(csvfile):
    check_valid_trace(csvfile)
    with open(csvfile) as f:
        f_csv = csv.DictReader(f)
        for row in f_csv:
            print(row['per'])
    with open(csvfile) as f:
        f_csv = csv.reader(f)
        headings = next(f_csv)
        Row = namedtuple('Row', headings)
        for r in f_csv:
            row = Row(*r)


if __name__=="__main__":
    parser = argparse.ArgumentParser(
        description='Trace generator'
    )
    parser.add_argument("-v", "--verbose", help="increase output verbosity",
                        action="store_true")
    args = parser.parse_args()
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    trace_root = "../traces"
    trace_path = trace_root+"/"+"trace1.csv"
    trace_length = 1000000
    trace = gen_random_trace_normal(trace_length)
    write_trace_as_csv(trace, trace_path)
   # display_csv_as_trace(trace_path)