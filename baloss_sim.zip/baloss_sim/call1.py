#Created by Wei Lai on 2020/12/14 22:51 (UTC+8)
#The main loop of the BaLoss-Simulator
#Which is used for the Bandit Model training and evaluation
#It import a network trace and a video, then repeatedly play
#the video according to the trace
#give feedback to Bandit on a real-time nature.
#The result is outputed using a Model

import os
import argparse
import logging
from base.Simulator import Sim_config,Simulator,Sim_mode

if __name__=="__main__":
    parser = argparse.ArgumentParser(
        description='Interface to the Bandit'
    )
    parser.add_argument("-v", "--verbose", help="increase output verbosity",
                        action="store_true")
    args = parser.parse_args()
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    logging.debug("Start State 1: Initialization...")
    #read the b.csv
    #start with state 1, initialization
    #read the sim configure (trace file, video file, repeating methods, mode)
    #Instantiate Simulator
    sim_config = Sim_config("traces/r1-E3.csv","videos/video1.mp4","r1.csv",100,Sim_mode.Repeat) #try 1000
    simulator = Simulator(sim_config)
    simulator.start()
    logging.debug("Transit to State 2: Learning...")
    #transit to state 2, learning state
    #repeat until the stoping signal from Bandit
        #write a state to a.csv and Log it to the raw QoE Log
        #read an action from b.csv [make sure that this is indeed a new result, need a signal]
        #wait for a feedback interval
    logging.debug("Transit to State 3: Tearing Down...")
    #close the files and exit 0
