def qoe_model_infer(ber,per,bandwidth,rtt,r,c,f):
    max_r = 25000000
    max_c = 1472
    max_f = 255
    ber = float(ber)
    per = float(per)
    bandwidth = round(bandwidth)
    rtt = round(rtt)
    delay = (1/2 + f/max_f + r/max_r) * rtt
    #if delay > 500:
    #    delay = 500
    # Bandit 1.4: Change the formula for calculating loss.
    alpha = 1
    beta = 1
    sigma = 10000
    loss = (ber * c / max_c + per * (1 - alpha * f/max_f) + per*(1 - beta * r/max_r)/sigma)
    #if loss >= 1:
    #    loss = 0.99
    goodput = bandwidth * (1/(1+f/max_f)) * 1.25
    return (delay,loss,goodput)


def qoe_model_infer2(ber,per,bandwidth,rtt,r,c,f):
    max_r = 25000000
    max_c = 1472
    max_f = 255
    ber = float(ber)
    per = float(per)
    bandwidth = round(bandwidth)
    rtt = round(rtt)
    delay = (rtt/2 + f/max_f*rtt + r/max_r*rtt) *0.8
    if delay > 500:
        delay = 500
    loss = (ber * c / max_c + per * (f/max_f) + per*(r/max_r)/10000) * 0.8
    if loss >= 1:
        loss = 0.99
    goodput = bandwidth * (1/(1+f/max_f)) * 1.25
    ber = ber
    return (delay,loss,goodput,ber)
