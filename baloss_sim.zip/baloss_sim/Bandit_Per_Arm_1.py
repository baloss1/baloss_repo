#created by Lai Wei on 2021/01/08 15:17 (UTC +8)
#This program do impl the bandit learning
#according to the reference code in the Tutorial of the 
#Google tutorial https://www.tensorflow.org/agents/tutorials/per_arm_bandits_tutorial
#
import functools
import matplotlib.pyplot as plt
import numpy as np
import csv
import random
import tensorflow as tf
from ipcqueue import posixmq
import GlobalQueue as Q


from tf_agents.bandits.agents import lin_ucb_agent
from tf_agents.bandits.environments import stationary_stochastic_per_arm_py_environment as p_a_env
from tf_agents.bandits.metrics import tf_metrics as tf_bandit_metrics
from tf_agents.drivers import dynamic_step_driver
from tf_agents.environments import tf_py_environment
from tf_agents.replay_buffers import tf_uniform_replay_buffer
from tf_agents.specs import tensor_spec
from tf_agents.trajectories import time_step as ts

# Clear any leftover state from previous colabs run.
# (This is not necessary for normal programs.)
#tf.compat.v1.reset_default_graph()

tf.compat.v1.enable_resource_variables()
tf.compat.v1.enable_v2_behavior()
nest = tf.compat.v2.nest

# The dimension of the global features.
GLOBAL_DIM = 3
# The elements of the global feature will be integers in [-GLOBAL_BOUND, GLOBAL_BOUND).
GLOBAL_BOUND = 10000 
# The dimension of the per-arm features.
PER_ARM_DIM = 4 
# The elements of the PER-ARM feature will be integers in [-PER_ARM_BOUND, PER_ARM_BOUND).
PER_ARM_BOUND = 5 
# The variance of the Gaussian distribution that generates the rewards.
VARIANCE = 1000.0 
# The elements of the linear reward parameter will be integers in [-PARAM_BOUND, PARAM_BOUND).
PARAM_BOUND = 20 

NUM_ACTIONS = 10000 
BATCH_SIZE = 1 

# Parameter for linear reward function acting on the
# concatenation of global and per-arm features.
reward_param = list(np.random.randint(
      -PARAM_BOUND, PARAM_BOUND, [GLOBAL_DIM + PER_ARM_DIM]))

arm_features = [[0 for i in range(4)] for j in range(10000)]  # @param
for i in range(10):
    for j in range(10):
        for k in range(10):
            for s in range(10):
                arm_features[1000 * i + 100 * j + 10 * k + s] = [i, j, k, s] # @param

def global_context_sampling_fn():
  """This function generates a single global observation vector."""
  try:
      a_array = Q.qA.get()
      pre = np.array(a_array[0:3]).astype(np.float32)
  except:
      pre = np.array([10, 0.01, 1000]).astype(np.float32)
  print("sampling the global context:",pre)
  return pre

def per_arm_context_sampling_fn():
  """"This function generates a single per-arm observation vector."""
  index = random.randint(0,999)
  return np.array(arm_features[index]).astype(np.float32)

def linear_normal_reward_fn(x):
  """This function generates a reward from the concatenated global and per-arm observations."""
  try:
    Q.qB.put(([str(x[3]*0.1), str(x[4]*0.1), str(x[5]*0.1), str(x[6]*0.1)]))
    print(([str(x[3] * 0.1), str(x[4] * 0.1), str(x[5] * 0.1), str(x[6]*0.1)]))
  except:
    Q.qB.put(([str(0.1), str(0.1), str(0.1), str(0.1)]))
    print(([str(0.1), str(0.1), str(0.1), str(0.1)]))
  # TODO: inputReward is gotten by not used, may change this behavior in the future
  try:
    inputReward = np.array(Q.qC.get()).astype(np.float32)
  except:
    inputReward = 4.8
  mu = np.dot(x, reward_param)
  return np.random.normal(mu, VARIANCE)

per_arm_py_env = p_a_env.StationaryStochasticPerArmPyEnvironment(
    global_context_sampling_fn,
    per_arm_context_sampling_fn,
    NUM_ACTIONS,
    linear_normal_reward_fn,
    batch_size=BATCH_SIZE
)
per_arm_tf_env = tf_py_environment.TFPyEnvironment(per_arm_py_env)

print('observation spec: ', per_arm_tf_env.observation_spec())
print('\nAn observation: ', per_arm_tf_env.reset().observation)

action = tf.zeros(BATCH_SIZE, dtype=tf.int32)
time_step = per_arm_tf_env.step(action)
print('\nRewards after taking an action: ', time_step.reward)

observation_spec = per_arm_tf_env.observation_spec()
time_step_spec = ts.time_step_spec(observation_spec)
action_spec = tensor_spec.BoundedTensorSpec(
    dtype=tf.int32, shape=(), minimum=0, maximum=NUM_ACTIONS - 1)

agent = lin_ucb_agent.LinearUCBAgent(time_step_spec=time_step_spec,
                                     action_spec=action_spec,
                                     accepts_per_arm_features=True)

print('training data spec: ', agent.training_data_spec)

print('observation spec in training: ', agent.training_data_spec.observation)

print('chosen arm features: ', agent.training_data_spec.policy_info.chosen_arm_features)

def _all_rewards(observation, hidden_param):
  """Outputs rewards for all actions, given an observation."""
  hidden_param = tf.cast(hidden_param, dtype=tf.float32)
  global_obs = observation['global']
  per_arm_obs = observation['per_arm']
  num_actions = tf.shape(per_arm_obs)[1]
  tiled_global = tf.tile(
      tf.expand_dims(global_obs, axis=1), [1, num_actions, 1])
  concatenated = tf.concat([tiled_global, per_arm_obs], axis=-1)
  rewards = tf.linalg.matvec(concatenated, hidden_param)
  return rewards

def optimal_reward(observation):
  """Outputs the maximum expected reward for every element in the batch."""
  return tf.reduce_max(_all_rewards(observation, reward_param), axis=1)

regret_metric = tf_bandit_metrics.RegretMetric(optimal_reward)

num_iterations = 3000# @param
steps_per_loop = 1 # @param

replay_buffer = tf_uniform_replay_buffer.TFUniformReplayBuffer(
    data_spec=agent.policy.trajectory_spec,
    batch_size=BATCH_SIZE,
    max_length=steps_per_loop)

observers = [replay_buffer.add_batch, regret_metric]

driver = dynamic_step_driver.DynamicStepDriver(
    env=per_arm_tf_env,
    policy=agent.collect_policy,
    num_steps=steps_per_loop * BATCH_SIZE,
    observers=observers)

regret_values = []

for _ in range(num_iterations):
  driver.run()
  loss_info = agent.train(replay_buffer.gather_all())
  replay_buffer.clear()
  regret_values.append(regret_metric.result())

# Pass -1 as a stop signal to qB, so that simulator.py will be stopped
Q.qB.put(([str(-1), str(-1), str(-1), str(-1)]))
# Close and unlink all queues here.
Q.qB.close()
Q.qB.unlink()
Q.qA.close()
Q.qA.unlink()
Q.qC.close()
Q.qC.unlink()
#plt.plot(regret_values)
#plt.title('Regret of LinUCB on the Linear per-arm environment')
#plt.xlabel('Number of Iterations')
#_ = plt.ylabel('Average Regret')
