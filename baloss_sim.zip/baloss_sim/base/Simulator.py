#Created by Wei Lai on 2020/12/15 11:00 (UTC+8)
#Simulator Class impl

import time
import logging
import tensorflow as tf
from enum import Enum, unique
import csv
import numpy as np
from models.qoe_infer_model_1 import qoe_model_infer, qoe_model_infer2
from utils.QoELogger import QoELogger
from stats.QoE import qoe_1
import pandas as pd
from ipcqueue import posixmq
import GlobalQueue as Q

#The enum class of the Simulation Mode
#Repeat: Repeatedly play the video over the trace
#        if the trace is over, then repeat the trace
#Flipflop: TODO: impl another mode
@unique
class Sim_mode(Enum):
    Repeat = 1
    Flipflop = 2

#The confiuration class includes all configure needed for the Simulator
#tracefile: The network trace
#videofile: The video file path
#logfile: The output log
#interval: The interval between two records in output log
#mode: Sim_mode
class Sim_config:
    def __init__(self,tracefile,videofile,logfile,interval,mode):
        self.tracefile = tracefile
        self.videofile = videofile
        self.interval = interval
        self.logfile = logfile
        self.mode = mode

class NetworkState:
    def __init__(self,tracefile):
        self.tracefile = tracefile
        self.per = 0
        self.ber = 0
        self.bandwidth = 0
        self.rtt = 0
        self.f_csv = pd.read_csv(self.tracefile)

    def __str__(self):
        return str(self.per)+','+str(self.ber)+','+str(self.bandwidth)+','+str(self.rtt)

    def update(self,t):
        #TODO:add the network state updating codes
        #TODO:read the tracefile a time t and fill in the member variables
        #TODO: handle the case that the trace is not long enough
        row = self.f_csv.iloc[t]
        self.per = row["per"]
        self.ber = row["ber"]
        self.bandwidth = row["bandwidth"]
        self.rtt = row["rtt"]
        logging.debug("updated network states at time " + str(t) + ":"+self.__str__())



#The main class impl the Simulator core logic
class Simulator:
    def __init__(self, sim_config):
        logging.debug("Simulator Initialization...")
        self.tracefile = sim_config.tracefile
        self.videofile = sim_config.videofile
        self.interval = sim_config.interval
        self.logfile = sim_config.logfile
        self.mode = sim_config.mode
        #init the timepoint to be 0
        self.t = 0
        #maintain the current r,c,f
        #r: the receive buffer size in bytes
        #c: lite checksum coverage in bytes
        #f: fec coverage [0,255]
        self.r = 1000000
        self.c = 1472
        self.f = 1
        self.network_state = NetworkState(self.tracefile)
        self.qoe_logger = QoELogger(self.logfile,0)
        self.qoe_logger_action = QoELogger("action_trace.csv",1)

    def start(self):
        logging.debug("Simulator Starting...")
        #read the video resolution
        n = 0
        print("Enter simulator")
        while (True):
            #timepoint plus 1
            logging.debug("Simulator at time "+str(self.t))
            self.t += 1
            self.network_state.update(self.t)
            # Write the 'delay', 'loss', 'goodput','ber'
            Q.qA.put([str(int(self.network_state.rtt/2)), str(float(self.network_state.per+self.network_state.ber)),str(float(self.network_state.bandwidth)), str(float(self.network_state.ber))])
            #read the action from Bandit
            pre = np.array(Q.qB.get()).astype(np.float32)
            # Break the loop to stop the program if a stop signal is read in, i.e., -1.
            if int(pre[0]) == -1:
                break
            print("Finish Reading.")
            self.r, self.c, self.f = pre[0],pre[1],pre[2]
            print("Current R,C,F:",self.r," ",self.c," ",self.f)
            self.r = self.r * 25000000
            self.c = self.c * 1472
            self.f = self.f * 255
            raw_qoe_action_trace = [self.r, self.c, self.f]
            self.qoe_logger_action.record(raw_qoe_action_trace)
            #raw_qoe is a (delay,loss,goodput) tuple
            # Bandit 1.4: Change qoe_model_infer2 to qoe_model_infer
            raw_qoe = qoe_model_infer(self.network_state.per,self.network_state.ber,
                                      self.network_state.bandwidth,self.network_state.rtt,self.r,self.c,self.f)
            print("delay: ", raw_qoe[0], " loss: ", raw_qoe[1], " goodput: ", raw_qoe[2])
            #output qoe to c.csv as the reward for bandit's action
            qoe = qoe_1(raw_qoe[0],raw_qoe[1],raw_qoe[2])
            #qoe = 1000
            Q.qC.put([str(qoe)])
            print("Rewarding QoE: ", qoe)
            print("Finish Writing.")

            #TODO:log the QoE
            logging.debug(raw_qoe)
            self.qoe_logger.record(raw_qoe)
            #cur_qoe = qoe1(raw_qoe[0],raw_qoe[1],raw_qoe[2])
            #output to the Bandit input
            #sleep for interval, simulate the sampling speed
            #time.sleep(self.interval/1000)
            #time.sleep(0.4)
            n += 1
            print(n)
